package com.bigsing.fakemap.hooks;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by sing on 2017/4/18.
 */

public class HookerMap {
    public static void hook(XC_LoadPackage.LoadPackageParam param) {

    }

}



