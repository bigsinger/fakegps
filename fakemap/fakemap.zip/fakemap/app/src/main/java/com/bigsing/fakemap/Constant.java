package com.bigsing.fakemap;

/**
 * Created by sing on 2017/4/18.
 */

public class Constant {
    public static final String TAG = "FAKEMAP";
    public static final String PACKAGE_THIS = "com.bigsing.fakemap";
    public static final String FILENAME_ACTIVE = "active";
}
