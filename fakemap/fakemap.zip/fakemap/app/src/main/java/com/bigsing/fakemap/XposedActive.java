package com.bigsing.fakemap;

/**
 * Created by sing on 2017/4/18.
 */

public class XposedActive {
    public static boolean isActive() {
        return false;
    }
}
